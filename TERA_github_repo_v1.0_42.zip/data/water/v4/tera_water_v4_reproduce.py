#!/usr/bin/env python3
"""TERA Water v4 — reproducible numeric anchors (IAPWS IF97 via iapws package).

This script evaluates a subset of water anomaly "numeric anchors" from the TERA catalog
using the open-source `iapws` implementation of IAPWS-IF97.
Outputs:
  - CSV with computed values at specified conditions

Install:
  pip install iapws pandas

Run:
  python tera_water_v4_reproduce.py

Notes:
  - Many anomaly items are structural/qualitative and require separate datasets
    (e.g., ice polymorph counts, nucleation rates, diffusion in supercooled water).
    v4 focuses on the strongest thermo/transport anchors that are directly computable
    from IAPWS formulations.
"""

import numpy as np
import pandas as pd
from iapws import IAPWS97

P_ATM_MPA = 0.101325  # 1 atm in MPa for IF97 inputs

def compute_row(code, desc, kind, T_C=None, P_MPa=None, x=None):
    row = dict(
        id=code,
        anomaly=desc,
        kind=kind,
        T_C=T_C,
        P_MPa=P_MPa,
        quality_x=x,
        value=np.nan,
        units="",
        method="IAPWS97 (iapws)",
        notes=""
    )
    try:
        if kind == "hvap":
            # Enthalpy of vaporization at saturation: (h_g - h_f) at given T
            wl = IAPWS97(T=T_C + 273.15, x=0)
            wv = IAPWS97(T=T_C + 273.15, x=1)
            row["value"] = (wv.h - wl.h) * 1000.0  # kJ/kg -> J/kg
            row["units"] = "J/kg"
            row["notes"] = "Computed as (h_g - h_f) at saturation."
            return row

        if kind == "sat_pressure":
            ws = IAPWS97(T=T_C + 273.15, x=0)
            row["value"] = ws.P * 1e6  # MPa -> Pa
            row["units"] = "Pa"
            row["notes"] = "Saturation pressure from IF97."
            return row

        # General state
        if x is not None:
            w = IAPWS97(T=T_C + 273.15, x=x)
        else:
            w = IAPWS97(T=T_C + 273.15, P=P_MPa)

        if kind == "density":
            row["value"] = w.rho
            row["units"] = "kg/m^3"
        elif kind == "cp":
            row["value"] = w.cp * 1000.0  # kJ/kgK -> J/kgK
            row["units"] = "J/(kg·K)"
        elif kind == "surface_tension":
            row["value"] = w.sigma
            row["units"] = "N/m"
        elif kind == "viscosity":
            row["value"] = w.mu
            row["units"] = "Pa·s"
        elif kind == "thermal_conductivity":
            row["value"] = w.k
            row["units"] = "W/(m·K)"
        elif kind == "dielectric":
            row["value"] = w.epsilon
            row["units"] = "1"
        elif kind == "sound_speed":
            row["value"] = w.w
            row["units"] = "m/s"
        elif kind == "thermal_expansion":
            row["value"] = w.alfav
            row["units"] = "1/K"
        else:
            row["notes"] = "Kind not implemented."
    except Exception as e:
        row["notes"] = f"Computation error: {e}"
    return row

def main():
    rows = []
    # Core numeric anchors
    rows += [
        compute_row("A01", "Density maximum near 4°C", "density", T_C=3.98, P_MPa=P_ATM_MPA),
        compute_row("A03", "Heat capacity near 25°C", "cp", T_C=25.0, P_MPa=P_ATM_MPA),
        compute_row("A04", "Enthalpy of vaporization at 100°C (sat)", "hvap", T_C=100.0),
        compute_row("A06", "Surface tension at 20°C", "surface_tension", T_C=20.0, P_MPa=P_ATM_MPA),
        compute_row("A10", "Static dielectric constant near 25°C", "dielectric", T_C=25.0, P_MPa=P_ATM_MPA),
        compute_row("A20", "Viscosity at 20°C", "viscosity", T_C=20.0, P_MPa=P_ATM_MPA),
        compute_row("A19", "Thermal conductivity at 25°C", "thermal_conductivity", T_C=25.0, P_MPa=P_ATM_MPA),
        compute_row("A13", "Sound speed at 20°C", "sound_speed", T_C=20.0, P_MPa=P_ATM_MPA),
        # Thermal expansion sign flip around 4°C (demonstrates negative thermal expansion region)
        compute_row("A11a", "Thermal expansion at 0°C (α<0)", "thermal_expansion", T_C=0.0, P_MPa=P_ATM_MPA),
        compute_row("A11b", "Thermal expansion at 2°C (α<0)", "thermal_expansion", T_C=2.0, P_MPa=P_ATM_MPA),
        compute_row("A11c", "Thermal expansion at 6°C (α>0)", "thermal_expansion", T_C=6.0, P_MPa=P_ATM_MPA),
        compute_row("A31", "Saturation vapor pressure at 20°C", "sat_pressure", T_C=20.0),
    ]
    df = pd.DataFrame(rows)
    out = "TERA_Water_v4_repro_values.csv"
    df.to_csv(out, index=False)
    print(f"Wrote: {out}")
    print(df[["id","kind","T_C","P_MPa","quality_x","value","units","notes"]])

if __name__ == "__main__":
    main()
