# Start Here (TERA)

Recommended reading order:

1) `papers/master/TERA_arXiv_MasterPaper_v2.pdf`  *(arXiv-ready master draft)*
2) `docs/public/TERA_Public_1Pager.pdf`
3) `docs/public/TERA_Manual_v1_Specification_Guide.pdf`
4) `docs/public/TERA_Disclaimer_Public_Use_and_Responsibility.pdf`
5) `docs/notation/TERA_HardIndex_BlindTest_PromptSheet.pdf`

Examples:
- Water: `papers/water/`
- Lightning: `papers/lightning/`
- Batteries: `papers/batteries/`
- Hydrogen: `papers/hydrogen/`
- Alzheimer: `papers/alzheimer/`
- Compute: `papers/compute/`


## Reader types (pick your path)

### If you're a scientist / reviewer
Start with:
- `papers/master/TERA_arXiv_MasterPaper_v2.pdf`
- `docs/public/TERA_Disclaimer_Public_Use_and_Responsibility.pdf`

### If you're an engineer / developer
Start with:
- `examples/quickstart_TERA.md`
- `examples/canonical_example_TERA.md`
- `docs/public/TERA_Manual_v1_Specification_Guide.pdf`
### If you're a clinician / applied medical user
Start with:
- `papers/alzheimer/TERA_Alzheimer_v1_ThreePerspectives_Clin_Research_Tech.pdf`

### If you're using TERA with an AI model
Start with:
- `docs/notation/TERA_HardIndex_BlindTest_PromptSheet.pdf`
- `docs/public/TERA_AI_vs_NoAI_CriticalComparison.pdf`
