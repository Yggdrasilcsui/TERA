# arXiv Submission (LaTeX) – v10

This folder contains an arXiv/Overleaf-ready LaTeX manuscript with BibTeX.

## Files
- `main.tex` (compile this)
- `references.bib` (BibTeX database; replace/extend with your preferred primary sources)
- `figures/` (optional)

## Overleaf workflow
1) Upload this folder as a ZIP to Overleaf
2) Compile `main.tex`
3) Edit author, affiliation, and expand the Examples section if desired
4) Add/replace BibTeX entries with primary sources used in your domain PDFs

## arXiv workflow
arXiv typically prefers LaTeX sources. Upload the contents of this folder (or a ZIP of it).
