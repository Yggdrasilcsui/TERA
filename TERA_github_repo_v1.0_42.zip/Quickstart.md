# Quickstart (TERA / TERA-Q)

**Goal:** turn a narrative claim into a **Minimal Testable Statement (MTS)** and evaluate it with a deterministic gate:

- **ACCEPT** = consistent under constraints and evidence
- **DEFER**  = not identifiable / not enough information
- **REJECT** = inconsistent / violates constraints Vene

---

## 1) Minimal example (TERA-Q gate)

**Claim:** *“Signal dominates context and artefacts.”*

1. Provide a measurement `y`
2. Provide a model prediction `ŝ` (or reconstruction)
3. Evaluate whether `gap(y, ŝ)` remains robust under a deterministic Γ (gamma) artefact/context set

---

## 2) Run the reference engine (Python)

From the repo root:

```bash
python3 docs/notation/code_reference_v2/teraq_v2.py
```

Optional (time-closure pro layer):

```bash
python3 docs/notation/code_reference_v2/teraq_timeclosure_pro.py
```

---

## 3) What you should see

The engine returns:

- `gate ∈ {ACCEPT, DEFER, REJECT}`
- evidence values (gap, best artefact pair, etc.)

**Important:** AI is *optional* and not a truth oracle.  
Use AI only as a **consistency layer** to reduce narrative drift when mapping claims → MTS.

---

## 4) Next step

Read:

- `README.md`
- `docs/notation/` (formal notation PDFs)
- `docs/notation/code_reference_v2/` (reference code)
