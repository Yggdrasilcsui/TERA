**Important:** TERA introduces **no new physics**. It is a validation/accounting protocol (reasoning harness) over existing models and measurements.

## TERA in 60 seconds (canonical demo)

*Domains are demonstrations of the method — not claims of completeness.*

**Claim:** “A sprite (TLE) can occur without a parent lightning discharge.”

**MTS:** A sprite occurs **iff** a parent discharge produces an upper-atmosphere electric field above the local breakdown threshold for duration Δt,
with correlated optical + VLF/ELF signatures.

**Constraints:** active storm; altitude 50–90 km; Δt < 50 ms after parent discharge.

**Minimal test plan:** high-speed camera + photometer + VLF/ELF receiver + lightning timestamping.

**Falsifier:** no parent discharge measured in the causal window AND an isolated sprite is claimed.

**Gate output:** δ = **REJECT**, π = high (budget/causality violation). Missing Set: none.

### Dirty-claim example (what TERA is for)

**Dirty claim:** “I heard sprites sometimes appear by themselves, so maybe they don’t need a parent discharge.”

**TERA action:** This is **not** an MTS yet → it becomes **DEFER** until you provide:
- time window (Δt)
- altitude band
- sensor modality (optical / VLF / both)
- falsifier (what would disprove it?)

**DEFER is a good outcome:** it returns the *smallest missing measurement set* needed to decide.



## Start Here
See `START_HERE.md` for the recommended reading order.

# TERA (Information–Phase–Space–Time–Dynamics)

TERA is a structured reasoning & validation framework that converts questions or observations into **testable statements**.
It outputs one of three outcomes:

- **ACCEPT** — consistent with constraints and test plan
- **REJECT** — violates constraints / budgets
- **DEFER (WAIT)** — missing information (requires constraints or measurements)

## Core ideas (very short)
- **Budgets / constraints (C):** nothing comes from nothing  
- **Missing constraints (M):** unknowns are listed explicitly  
- **Validation gate:** prevents false certainty  
- **Pipeline (2:3:5:3:2):** causal direction → properties → interactions → properties → causal direction

## Start here (PDFs)
- `docs/public/TERA_Public_1Pager.pdf`
- `docs/public/TERA_Manual_v1_Specification_Guide.pdf`
- `docs/public/TERA_Disclaimer_Public_Use_and_Responsibility.pdf`

## Reproducibility (Water examples)
See `papers/water/` and `data/water/`.

## License
See `LICENSE`.

## Citation
See `CITATION.cff`.

## Start here (recommended)
If you're new to TERA, read in this order:

1) **Public 1-Pager**
   `docs/public/TERA_Public_1Pager.pdf`

2) **Manual (simple + practical)**
   `docs/public/TERA_Manual_v1_Specification_Guide.pdf`

3) **Disclaimer (responsible use)**
   `docs/public/TERA_Disclaimer_Public_Use_and_Responsibility.pdf`

4) **Hard-Index Prompt Sheet (for testing)**
   `docs/notation/TERA_HardIndex_BlindTest_PromptSheet.pdf`

Then explore the examples:
- Compute: `papers/compute/`
- Water: `papers/water/`
- Lightning: `papers/lightning/`
- Hydrogen: `papers/hydrogen/`
- Alzheimer: `papers/alzheimer/`


## Responsible use
TERA is provided for scientific reasoning, education, and risk reduction.

**Prohibited misuse:** this project must not be used to design, optimize, or operationalize harmful applications.
It is intended for validation, interpretation, and test planning.

This material is provided **as-is**, without warranty. The authors assume no liability for misuse.


Notes:
- Hydrogen includes v1–v4 PDFs.
- Alzheimer includes v2–v5 PDFs (v1 overview can be added on request).

- Compute includes v1–v6 PDFs (QC + CMOS + Memory + Topology + Materials).


## Batteries
- Batteries: `papers/batteries/`


### Real-world messy claim example (what people actually say)

**Messy claim:** “Water does weird things. Maybe it’s quantum magic and science just can’t explain it.”

**TERA rewrite (MTS suggestion):**
> A specific water property p(T,P) shows a reproducible extremum under stated regime (T,P,ρ), consistent with competing microstructure hypotheses
> (e.g., hydrogen-bond network motifs) and measurable via an agreed protocol.

**TERA gate outcome:** δ = **DEFER** until you specify:
- which property p (density? Cp? viscosity? compressibility?)
- regime (temperature/pressure window)
- measurement method (protocol + uncertainty)
- falsifier (what observation would contradict the claim)


### Confidence calibration (π) — minimal rule of thumb

TERA uses π as a *conditional* confidence indicator (always tied to the declared regime).

- **π = high** → budget closure is satisfied OR a hard falsifier triggers, **and** ≥2 independent measurement channels support the outcome.
- **π = medium** → partial closure, 1 strong measurement channel, low confound risk.
- **π = low** → weak closure, high confound risk, missing falsifiers (typically DEFER).

(You can replace π with any calibrated scoring scheme — TERA’s core requirement is that the confidence logic must be explicit.)


## Code references

- `docs/notation/TERA-Q_CodeReference_LaTeX_PHP_v1.pdf`
- `docs/notation/TERA-Q_CodeReference_Python_CSharp_v1.pdf`


## Quickstart

- See **START_HERE.md**
- Core docs: `docs/`
- Deterministic gamma points: `data/gamma_points_256.csv`
- Reference code: `docs/notation/code_reference_v2/`

## AI usage (optional)

TERA / TERA‑Q can be executed **manually** or with **AI assistance**.

**Version A — AI‑assisted gating**
- AI can be used as a *consistency layer* to map narrative / ambiguous claims into **Minimal Testable Statements (MTS)**.
- AI can help apply the gate logic (**ACCEPT / DEFER / REJECT**) under explicit constraints.

**Version B — AI helps expose bias (recommended framing)**
- AI is **not** treated as truth.
- It is used to reduce human narrative drift and to stress‑test whether a claim survives **constraint closure**.
- The gate remains **deterministic and auditable**.

> **Warning:** AI is optional and **not a truth oracle**.

---

**v42 note:** Answers are cheap. Constraints are expensive.

## v42 Easter Egg (for fun)

We tagged this repo as **v42** as a small nod to sci‑fi culture. In TERA terms:

- **42 = “closure”**: when budgets close, stories stop arguing.
- If you want the tiny joke artifact, see: `docs/easter_egg/42.md`.

