"""
TERA / TERA-Q (v2) — minimal, auditable reference implementation

Goal:
  Decide whether a Claim about a latent world state s is:
    ACCEPT  (+1): supported under admissible context/artifact class Γ
    DEFER   ( 0): non-identifiable / insufficient separation
    REJECT  (-1): violated hard constraints / budgets / falsifier

Core idea:
  y = M(s; ρ) + a(ρ; θ) + ε
  where ρ is context, a is an artifact channel, ε is noise.

TERA-Q adds explicit adversarial / robust checks over Γ:
  Is there a (ρ, θ) ∈ Γ that explains y "without" s?
  If yes → DEFER (cannot uniquely attribute signal).
"""

from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum
from typing import Callable, Dict, Iterable, List, Optional, Tuple
import math
import random
random.seed(0)  # deterministic sampling

Vector = List[float]


class Gate(IntEnum):
    REJECT = -1
    DEFER = 0
    ACCEPT = 1


@dataclass(frozen=True)
class Budgets:
    """Hard limits: time, energy, compute, etc. Treated as non-negotiable."""
    max_time_s: float = 1e9
    max_compute: float = 1e9
    max_energy_j: float = 1e18


@dataclass(frozen=True)
class Claim:
    """A claim is made testable by mapping it to MTS units."""
    text: str
    mts: List[str]  # Minimal Testable Statements (strings here, structured in practice)


@dataclass(frozen=True)
class Evidence:
    """What the gate sees: scores, bounds, and reasons."""
    score_signal: float
    score_artifact: float
    worst_case_gap: float
    notes: List[str]


# ---------- Minimal numeric helpers ----------

def l2(x: Vector) -> float:
    return math.sqrt(sum(v*v for v in x))

def sub(a: Vector, b: Vector) -> Vector:
    return [ai - bi for ai, bi in zip(a, b)]

def add(a: Vector, b: Vector) -> Vector:
    return [ai + bi for ai, bi in zip(a, b)]

def scale(a: Vector, k: float) -> Vector:
    return [k*ai for ai in a]


# ---------- Model interfaces ----------

ForwardModel = Callable[[Vector, Dict], Vector]
ArtifactModel = Callable[[Dict, Dict], Vector]
ScoreFn = Callable[[Vector], float]


@dataclass
class TERAQ:
    """
    TERA-Q engine:
      - forward model M(s; ρ)
      - artifact model a(ρ; θ)
      - Γ: admissible context/artifact set (sampler or enumerator)
      - budgets + hard falsifiers
    """
    M: ForwardModel
    A: ArtifactModel
    gamma_samples: Callable[[int], Iterable[Tuple[Dict, Dict]]]
    budgets: Budgets = Budgets()
    score: ScoreFn = l2
    accept_margin: float = 2.0   # how much better signal must be than artifacts
    defer_margin: float = 0.2    # near-ties are DEFER

    def gate(self, y: Vector, s_hat: Vector, claim: Claim) -> Tuple[Gate, Evidence]:
        notes: List[str] = []
        # 1) Budget / hard checks (placeholder; in real systems this is measured)
        if self.budgets.max_compute <= 0:
            return Gate.REJECT, Evidence(0, 0, 0, ["Budget violation: compute <= 0"])

        # 2) Fit signal model at estimate s_hat using a nominal context ρ0
        rho0: Dict = {"mode": "nominal"}
        y_sig = self.M(s_hat, rho0)
        r_sig = sub(y, y_sig)
        score_sig = self.score(r_sig)

        # 3) Worst-case artifact explanation over Γ
        #    We ask: can artifacts explain y about as well as the signal model?
        best_art = float("inf")
        best_pair: Optional[Tuple[Dict, Dict]] = None
        for rho, theta in self.gamma_samples(256):
            y_art = self.A(rho, theta)
            r_art = sub(y, y_art)
            sc = self.score(r_art)
            if sc < best_art:
                best_art = sc
                best_pair = (rho, theta)

        # 4) Compare
        gap = best_art - score_sig   # positive → signal explains better
        notes.append(f"score_sig={score_sig:.4g}, best_art={best_art:.4g}, gap={gap:.4g}")

        # 5) Decide
        #    - If artifacts can explain as well (gap small/negative) → DEFER.
        #    - If signal wins by a strong margin → ACCEPT.
        #    - If both are bad (no closure) → REJECT.
        if not math.isfinite(best_art) or not math.isfinite(score_sig):
            return Gate.REJECT, Evidence(score_sig, best_art, gap, notes + ["Non-finite scores"])

        if score_sig > 1e6 and best_art > 1e6:
            return Gate.REJECT, Evidence(score_sig, best_art, gap, notes + ["No closure: both fits poor"])

        if gap < self.defer_margin:
            return Gate.DEFER, Evidence(score_sig, best_art, gap, notes + ["Non-identifiable under Γ → DEFER"])

        if gap >= self.accept_margin:
            return Gate.ACCEPT, Evidence(score_sig, best_art, gap, notes + ["Signal robust under Γ → ACCEPT"])

        return Gate.DEFER, Evidence(score_sig, best_art, gap, notes + ["Inconclusive gap → DEFER"])


# ---------- Example: a toy 1D measurement with drift artifacts ----------

def M_linear(s: Vector, rho: Dict) -> Vector:
    k = 1.0 if rho.get("mode") == "nominal" else float(rho.get("gain", 1.0))
    b = float(rho.get("bias", 0.0))
    return [k*s[0] + b]

def A_drift(rho: Dict, theta: Dict) -> Vector:
    # artifact: context-dependent offset + small sinusoid (e.g., aliasing)
    offset = float(theta.get("offset", 0.0))
    wobble = float(theta.get("wobble", 0.0))
    t = float(rho.get("t", 0.0))
    return [offset + wobble*math.sin(2*math.pi*t)]

def gamma_sampler(n: int):
    """Deterministic Γ sampler.

    Loads precomputed Γ points from ../data/gamma_points_256.csv to ensure
    cross-language reproducibility (Python/C#/PHP). Falls back to a small
    Halton sequence if the CSV is missing.
    """
    import csv
    from pathlib import Path

    # repo layout: docs/notation/code_reference_v2/teraq_v2.py -> repo root is parents[3]
    csv_path = Path(__file__).resolve().parents[3] / "data" / "gamma_points_256.csv"
    rows = []
    if csv_path.exists():
        with csv_path.open("r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(row)

    def halton(i: int, base: int) -> float:
        f = 1.0
        r = 0.0
        while i > 0:
            f /= base
            r += f * (i % base)
            i //= base
        return r

    k = 0
    while k < n:
        if rows:
            row = rows[k % len(rows)]
            rho = {"t": float(row["rho_t"])}
            theta = {"offset": float(row["theta_offset"]), "wobble": float(row["theta_wobble"])}
        else:
            # deterministic fallback: Halton(2,3,5)
            i = (k % 256) + 1
            rho = {"t": halton(i, 2)}
            theta = {"offset": 2.0 * halton(i, 3) - 1.0, "wobble": 0.5 * halton(i, 5)}
        yield rho, theta
        k += 1

if __name__ == "__main__":
    engine = TERAQ(M=M_linear, A=A_drift, gamma_samples=gamma_sampler)
    claim = Claim(text="s is present", mts=["signal present vs artifact"])
    true_s = [0.8]
    y = add(M_linear(true_s, {"mode":"nominal"}), A_drift({"t":0.3}, {"offset":0.1, "wobble":0.2}))
    gate, ev = engine.gate(y=y, s_hat=[0.8], claim=claim)
    print(gate, ev)
