# Glossary (TERA)

- **C (Constraint/Budget):** conservation / bookkeeping rule (no free creation).
- **M (Missing constraints):** list of unknown parameters required to decide.
- **β (Beta):** effective medium/property mask (dissipation, relaxation, viscosity-like).
- **S (Topology/Structure):** network form / geometry / boundary-layer layout.
- **DEFER (WAIT):** output state when decision cannot be made without more constraints.
