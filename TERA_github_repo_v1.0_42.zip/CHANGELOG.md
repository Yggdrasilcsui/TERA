# Changelog

## v1.0.0 — 2026-01-22
- Public release seed: Manual, Notation, Disclaimer
- Water (41 anomalies) catalog + reproducibility appendix and datasets
- Lightning regimes + TLE coupling notes
- Validation gate, diamond/hypercube logic, accounting + tetrahedron memory notes
