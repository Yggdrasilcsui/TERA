# TERA Glossary (public)

**MTS (Minimal Testable Statement)**  
Smallest testable version of a claim, including at least one falsifier.

**Budget closure (C)**  
Accounting rule: “nothing comes from nothing” inside the declared system boundary.

**Missing Set (M)**  
The smallest set of missing constraints / measurements required to resolve a DEFER.

**Regime**  
The boundary conditions where a claim is supposed to hold (scale, medium, temperature, topology, etc.).

**Gate output δ**  
Decision symbol: ACCEPT / DEFER / REJECT.

**Confidence π**  
Confidence scalar π ∈ [0,1], always conditional on the declared regime.

**DEFER vs WAIT**  
DEFER: missing constraints prevent resolution.  
WAIT: temporal dependency exists (need more time steps / system evolution) before resolution.
