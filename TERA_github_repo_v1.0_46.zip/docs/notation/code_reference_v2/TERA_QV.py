"""
TERA-QV (v44) — quantum extension for stability-under-drift
=========================================================
This module provides a *minimal, readable* reference implementation of a
TERA-Q layer for a single qubit (and small-N extensions by stacking).


Additional concept in TERA-QV:
- **Effective space-viscosity** η_R: a dimensionless ratio capturing whether the
  stabilizing action (correction + filtering) dominates environmental drift/noise.
  If η_R is too small, the state-space behaves "runny" (fast drift); if large, it
  behaves "viscous" (damped, stable).

  η_R := (λ + γ) / (||L(ρ)|| + ||N(ρ)|| + ε)

TERA-QV can optionally *adapt* (λ, γ) to maintain η_R ≥ η_target within a safe cap.

Core idea (matching the TERA philosophy in this repo):
- **Signal** lives in a model space (here: a density matrix ρ).
- **Artefacts / context** live in environment couplings (Lindblad operators).
- **Time-closure** turns "truth" into "what remains stable across time".
- **Gate** emits {REJECT, DEFER, ACCEPT} based on constraints and stability.

This file intentionally stays "physics-clean":
- Lindblad master equation (open quantum system)
- Extra TERA term: correction-to-target + filter/projection

No claims of hardware optimality; this is a conceptual bridge that can be
plugged into control, estimation, or simulation pipelines.

Author: TERA project (reference implementation generated for v43)
License: same as repository
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Callable, Iterable, Optional, Sequence, Tuple

import numpy as np


# -----------------------------
# Helpers / basic linear algebra
# -----------------------------
def dag(A: np.ndarray) -> np.ndarray:
    """Conjugate transpose."""
    return A.conj().T


def comm(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Commutator [A,B] = AB - BA."""
    return A @ B - B @ A


def anticomm(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Anti-commutator {A,B} = AB + BA."""
    return A @ B + B @ A


def fro_norm(A: np.ndarray) -> float:
    """Frobenius norm."""
    return float(np.linalg.norm(A, ord="fro"))


def is_hermitian(rho: np.ndarray, atol: float = 1e-10) -> bool:
    return np.allclose(rho, dag(rho), atol=atol)


def trace_one(rho: np.ndarray, atol: float = 1e-10) -> bool:
    return np.allclose(np.trace(rho), 1.0, atol=atol)


def is_positive_semidefinite(rho: np.ndarray, atol: float = 1e-10) -> bool:
    # numerical eigenvalues can slightly dip below 0 due to fp error
    ev = np.linalg.eigvalsh((rho + dag(rho)) / 2.0)
    return bool(np.min(ev) >= -atol)


def project_diagonal(rho: np.ndarray) -> np.ndarray:
    """
    Simple dephasing projection Π[ρ]: keep only diagonal in computational basis.
    This corresponds to the "phase filter" view of TERA-Q.
    """
    out = np.zeros_like(rho)
    d = np.diag(rho)
    np.fill_diagonal(out, d)
    return out


# -----------------------------
# Gate logic (Accept/Defer/Reject)
# -----------------------------
class Gate(IntEnum):
    REJECT = -1
    DEFER = 0
    ACCEPT = +1

def effective_space_viscosity(
    rho: np.ndarray,
    model: "OpenQubitModel",
    config: "TERAQConfig",
) -> float:
    """Compute TERA-QV effective space-viscosity η_R.

    η_R compares stabilizing strength (λ+γ) against instantaneous drift/noise
    magnitudes induced by the open-system generator L(ρ) and the projector gap.

    Returns a dimensionless value; larger means more damping / 'viscosity'.
    """
    # Drift magnitude from the generator (Hamiltonian + Lindblad)
    Lrho = model.generator(rho)
    drift = np.linalg.norm(Lrho, ord="fro")

    # Noise / leak magnitude: distance to the projected subspace Π[ρ]
    proj = config.projector(rho)
    leak = np.linalg.norm(rho - proj, ord="fro")

    return (config.lam + config.gamma) / (drift + leak + config.eta_eps)


def adapt_gains_for_viscosity(
    rho: np.ndarray,
    model: "OpenQubitModel",
    config: "TERAQConfig",
) -> Tuple[float, float, float]:
    """Adapt (λ, γ) up to eta_cap to keep η_R ≥ eta_target.

    Returns (lam_eff, gamma_eff, eta_R).
    """
    eta = effective_space_viscosity(rho, model, config)
    lam_eff, gamma_eff = config.lam, config.gamma

    if not config.adapt_viscosity:
        return lam_eff, gamma_eff, eta

    if eta < config.eta_target:
        # Scale both gains proportionally; cap the multiplier for safety.
        mult = min(config.eta_cap, max(1.0, config.eta_target / max(eta, config.eta_eps)))
        lam_eff *= mult
        gamma_eff *= mult
        # Recompute eta using effective gains (approx; drift/leak unchanged instantaneously)
        eta = (lam_eff + gamma_eff) / (np.linalg.norm(model.generator(rho), ord="fro")
                                      + np.linalg.norm(rho - config.projector(rho), ord="fro")
                                      + config.eta_eps)

    return lam_eff, gamma_eff, eta



@dataclass(frozen=True)
class GateReport:
    gate: Gate
    distance: float
    drift: float
    note: str


# -----------------------------
# Lindblad + TERA-Q dynamics
# -----------------------------
@dataclass
class LindbladChannel:
    """One Lindblad jump operator with rate kappa."""
    C: np.ndarray
    kappa: float


@dataclass
class TERAQConfig:
    # Correction rate pulling toward target ρ*
    lam: float = 0.0
    # Filter / projection strength (dephasing-style)
    gamma: float = 0.0

    # --- TERA-QV additions (effective space-viscosity) ---
    eta_target: float = 1.0          # desired lower bound for η_R
    eta_cap: float = 10.0            # maximum multiplier for (λ, γ) adaptation
    eta_eps: float = 1e-12           # numerical epsilon in η_R
    adapt_viscosity: bool = True     # if True, adapt (λ, γ) to maintain η_R
    # Projection operator Π[ρ] (default: dephasing in computational basis)
    projector: Callable[[np.ndarray], np.ndarray] = project_diagonal

    # Gate thresholds
    eps_accept: float = 1e-3          # distance-to-target threshold
    eps_drift: float = 1e-6           # drift threshold (near-stationary)
    max_steps_for_accept: int = 10_000


@dataclass
class OpenQubitModel:
    """
    Open system model:
        dρ/dt = -i[H,ρ] + Σ_j κ_j (C_j ρ C_j† - 1/2 {C_j† C_j, ρ})
    """
    H: np.ndarray
    channels: Sequence[LindbladChannel]


def lindblad_rhs(rho: np.ndarray, model: OpenQubitModel) -> np.ndarray:
    """Right-hand side of Lindblad master equation (without TERA term)."""
    H = model.H
    rhs = -1j * comm(H, rho)
    for ch in model.channels:
        C, k = ch.C, ch.kappa
        rhs = rhs + k * (C @ rho @ dag(C) - 0.5 * anticomm(dag(C) @ C, rho))
    return rhs


def teraq_term(rho: np.ndarray, rho_star: np.ndarray, cfg: TERAQConfig) -> np.ndarray:
    """
    TERA-Q term (v43):
        T_TERA(ρ) = λ(ρ* - ρ) - γ(ρ - Π[ρ])

    Interpretation:
      - λ term: dissipative "pull" toward target state (stabilizing attractor)
      - γ term: filter that suppresses components outside admissible subspace
               (here: off-diagonals -> dephasing projection)
    """
    corr = cfg.lam * (rho_star - rho)
    filt = -cfg.gamma * (rho - cfg.projector(rho))
    return corr + filt


def master_rhs(rho: np.ndarray, model: OpenQubitModel, rho_star: np.ndarray, cfg: TERAQConfig) -> np.ndarray:
    return lindblad_rhs(rho, model) + teraq_term(rho, rho_star, cfg)


def euler_step(rho: np.ndarray, drho: np.ndarray, dt: float) -> np.ndarray:
    """Explicit Euler step with a minimal physical repair (trace + hermiticity)."""
    rho_new = rho + dt * drho
    # enforce hermiticity
    rho_new = (rho_new + dag(rho_new)) / 2.0
    # renormalize trace
    tr = np.trace(rho_new)
    if tr != 0:
        rho_new = rho_new / tr
    return rho_new


# -----------------------------
# Time-closure: stability across time
# -----------------------------
def simulate(
    rho0: np.ndarray,
    model: OpenQubitModel,
    rho_star: np.ndarray,
    cfg: TERAQConfig,
    dt: float = 1e-3,
    steps: int = 50_000,
) -> Tuple[np.ndarray, GateReport]:
    """
    Simulate the master equation and return final state + a GateReport.

    Gate rules (minimal):
      - REJECT if constraints violated (trace, hermiticity, positivity)
      - ACCEPT if distance-to-target and drift are both small
      - otherwise DEFER
    """
    rho = rho0.copy()
    prev_dist = fro_norm(rho - rho_star)
    drift = float("inf")

    for k in range(steps):
        drho = master_rhs(rho, model, rho_star, cfg)
        rho = euler_step(rho, drho, dt)

        # constraints check early
        if (not is_hermitian(rho)) or (not trace_one(rho)) or (not is_positive_semidefinite(rho)):
            return rho, GateReport(
                gate=Gate.REJECT,
                distance=fro_norm(rho - rho_star),
                drift=float("nan"),
                note="constraints violated (hermiticity/trace/positivity)",
            )

        dist = fro_norm(rho - rho_star)
        drift = abs(dist - prev_dist) / max(dt, 1e-12)
        prev_dist = dist

        if k >= 10 and dist < cfg.eps_accept and drift < cfg.eps_drift:
            return rho, GateReport(
                gate=Gate.ACCEPT,
                distance=dist,
                drift=drift,
                note="stable across time (time-closure satisfied)",
            )

    # Not converged -> DEFER
    return rho, GateReport(
        gate=Gate.DEFER,
        distance=fro_norm(rho - rho_star),
        drift=drift,
        note="not identifiable / not stable enough within horizon",
    )


# -----------------------------
# Example: 1-qubit demo setup
# -----------------------------
def pauli() -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    return sx, sy, sz


def ket0() -> np.ndarray:
    v = np.array([[1.0], [0.0]], dtype=complex)
    return v


def density_from_ket(ket: np.ndarray) -> np.ndarray:
    return ket @ dag(ket)


def amplitude_damping(gamma: float) -> LindbladChannel:
    """
    Standard amplitude damping jump operator:
      C = |0><1|, rate gamma
    """
    C = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex)
    return LindbladChannel(C=C, kappa=gamma)


def dephasing(gamma_phi: float) -> LindbladChannel:
    """
    Pure dephasing channel:
      C = σ_z, rate gamma_phi
    """
    _, _, sz = pauli()
    return LindbladChannel(C=sz, kappa=gamma_phi)


def demo() -> None:
    """
    Run a tiny demo:
      - environmental dephasing + weak Hamiltonian
      - TERA-Q pulls toward |0><0| and filters phase
    """
    sx, _, sz = pauli()
    H = 0.5 * sx  # simple drive
    model = OpenQubitModel(
        H=H,
        channels=[dephasing(0.05), amplitude_damping(0.02)],
    )
    rho0 = 0.5 * np.eye(2, dtype=complex)  # maximally mixed
    rho_star = density_from_ket(ket0())    # target ground state

    cfg = TERAQConfig(lam=0.3, gamma=0.2, eps_accept=5e-3, eps_drift=1e-5)

    rhoT, rep = simulate(rho0, model, rho_star, cfg, dt=1e-3, steps=200_000)
    print("Gate:", rep.gate.name, "distance:", rep.distance, "drift:", rep.drift)
    print("rho(T)=\n", rhoT)


if __name__ == "__main__":
    demo()
