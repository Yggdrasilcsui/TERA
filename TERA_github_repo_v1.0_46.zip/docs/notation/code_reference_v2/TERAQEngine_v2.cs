// TERA / TERA-Q (v2) — minimal, auditable reference implementation (C#)
// Target: .NET 6+ (no external deps)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.IO;

namespace TERAQ
{
    public enum Gate : int { Reject = -1, Defer = 0, Accept = 1 }

    public record Budgets(double MaxTimeS = 1e9, double MaxCompute = 1e9, double MaxEnergyJ = 1e18);

    public record Claim(string Text, IReadOnlyList<string> MTS);

    public record Evidence(double ScoreSignal, double ScoreArtifact, double WorstCaseGap, IReadOnlyList<string> Notes);

    public delegate double[] ForwardModel(double[] s, IDictionary<string, object> rho);
    public delegate double[] ArtifactModel(IDictionary<string, object> rho, IDictionary<string, object> theta);

    public sealed class TERAQEngine
    {
        private readonly ForwardModel _M;
        private readonly ArtifactModel _A;
        private readonly Func<int, IEnumerable<(IDictionary<string, object> rho, IDictionary<string, object> theta)>> _GammaSamples;

        public Budgets Budgets { get; init; } = new Budgets();
        public double AcceptMargin { get; init; } = 2.0;
        public double DeferMargin { get; init; } = 0.2;

        public TERAQEngine(
            ForwardModel M,
            ArtifactModel A,
            Func<int, IEnumerable<(IDictionary<string, object> rho, IDictionary<string, object> theta)>>? gammaSamples = null)
        {
            _M = M;
            _A = A;
            _GammaSamples = gammaSamples ?? DeterministicGammaPoints.FromCsv;
        }

        private static double L2(double[] x) => Math.Sqrt(x.Select(v => v * v).Sum());

        private static double[] Sub(double[] a, double[] b) => a.Zip(b, (ai, bi) => ai - bi).ToArray();

        public (Gate gate, Evidence evidence) Gate(double[] y, double[] sHat, Claim claim)
        {
            var notes = new List<string>();

            if (Budgets.MaxCompute <= 0)
                return (Gate.Reject, new Evidence(0, 0, 0, new[] { "Budget violation: compute <= 0" }));

            var rho0 = new Dictionary<string, object> { ["mode"] = "nominal" };
            var ySig = _M(sHat, rho0);
            var rSig = Sub(y, ySig);
            var scoreSig = L2(rSig);

            double bestArt = double.PositiveInfinity;
            (IDictionary<string, object> rho, IDictionary<string, object> theta)? bestPair = null;

            foreach (var (rho, theta) in _GammaSamples(256))
            {
                var yArt = _A(rho, theta);
                var rArt = Sub(y, yArt);
                var sc = L2(rArt);
                if (sc < bestArt)
                {
                    bestArt = sc;
                    bestPair = (rho, theta);
                }
            }

            var gap = bestArt - scoreSig; // positive → signal explains better
            notes.Add($"score_sig={scoreSig:g4}, best_art={bestArt:g4}, gap={gap:g4}");

            if (double.IsNaN(bestArt) || double.IsNaN(scoreSig) || double.IsInfinity(bestArt) || double.IsInfinity(scoreSig))
                return (Gate.Reject, new Evidence(scoreSig, bestArt, gap, notes.Concat(new[] { "Non-finite scores" }).ToArray()));

            if (scoreSig > 1e6 && bestArt > 1e6)
                return (Gate.Reject, new Evidence(scoreSig, bestArt, gap, notes.Concat(new[] { "No closure: both fits poor" }).ToArray()));

            if (gap < DeferMargin)
                return (Gate.Defer, new Evidence(scoreSig, bestArt, gap, notes.Concat(new[] { "Non-identifiable under Γ → DEFER" }).ToArray()));

            if (gap >= AcceptMargin)
                return (Gate.Accept, new Evidence(scoreSig, bestArt, gap, notes.Concat(new[] { "Signal robust under Γ → ACCEPT" }).ToArray()));

            return (Gate.Defer, new Evidence(scoreSig, bestArt, gap, notes.Concat(new[] { "Inconclusive gap → DEFER" }).ToArray()));
        }
    }

    internal static class DeterministicGammaPoints
    {
        // Shared across languages: reads ../data/gamma_points_256.csv relative to repository root.
        public static IEnumerable<(Dictionary<string, object> rho, Dictionary<string, object> theta)> FromCsv(int n)
        {
            var baseDir = AppContext.BaseDirectory;
            // Try a few likely roots: bin/Debug/... -> go up, or current dir.
            var candidates = new[]
            {
                Path.Combine(Directory.GetCurrentDirectory(), "data", "gamma_points_256.csv"),
                Path.Combine(baseDir, "..", "..", "..", "data", "gamma_points_256.csv"),
                Path.Combine(baseDir, "data", "gamma_points_256.csv"),
            };
            string? csvPath = candidates.FirstOrDefault(File.Exists);

            var rows = new List<(double rho_t, double theta_offset, double theta_wobble)>();
            if (csvPath != null)
            {
                using var sr = new StreamReader(csvPath);
                var header = sr.ReadLine(); // rho_t,theta_offset,theta_wobble
                while (!sr.EndOfStream)
                {
                    var line = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var parts = line.Split(',');
                    if (parts.Length < 3) continue;
                    rows.Add((
                        double.Parse(parts[0], CultureInfo.InvariantCulture),
                        double.Parse(parts[1], CultureInfo.InvariantCulture),
                        double.Parse(parts[2], CultureInfo.InvariantCulture)
                    ));
                }
            }

            static double Halton(int index, int b)
            {
                double f = 1.0, r = 0.0;
                while (index > 0)
                {
                    f /= b;
                    r += f * (index % b);
                    index /= b;
                }
                return r;
            }

            for (int k = 0; k < n; k++)
            {
                double rho_t, theta_offset, theta_wobble;
                if (rows.Count > 0)
                {
                    var row = rows[k % rows.Count];
                    rho_t = row.rho_t; theta_offset = row.theta_offset; theta_wobble = row.theta_wobble;
                }
                else
                {
                    int i = (k % 256) + 1;
                    rho_t = Halton(i, 2);
                    theta_offset = 2.0 * Halton(i, 3) - 1.0;
                    theta_wobble = 0.5 * Halton(i, 5);
                }

                var rho = new Dictionary<string, object> { ["t"] = rho_t };
                var theta = new Dictionary<string, object> { ["offset"] = theta_offset, ["wobble"] = theta_wobble };
                yield return (rho, theta);
            }
        }
    }

}
