<?php
mt_srand(0); // deterministic v2.1
/**
 * TERA / TERA-Q (v2) — minimal, auditable reference implementation (PHP 8.1+)
 *
 * y = M(s; rho) + A(rho; theta) + eps
 * Gate compares a fitted signal residual against best (worst-case) artifact residual over Γ.
 */

declare(strict_types=1);

namespace TERAQ;

enum Gate:int {
    case REJECT = -1;
    case DEFER  = 0;
    case ACCEPT = 1;
}

final class Budgets {
    public function __construct(
        public float $max_time_s = 1e9,
        public float $max_compute = 1e9,
        public float $max_energy_j = 1e18
    ) {}
}

final class Claim {
    /** @param string[] $mts */
    public function __construct(
        public string $text,
        public array $mts
    ) {}
}

final class Evidence {
    /** @param string[] $notes */
    public function __construct(
        public float $score_signal,
        public float $score_artifact,
        public float $worst_case_gap,
        public array $notes
    ) {}
}

final class TERAQEngine
{
    /** @var callable(array<float>, array<string,mixed>): array<float> */
    private $M;
    /** @var callable(array<string,mixed>, array<string,mixed>): array<float> */
    private $A;
    /** @var callable(int): iterable<array{0:array<string,mixed>,1:array<string,mixed>}> */
    private $gammaSamples;

    public Budgets $budgets;
    public float $accept_margin = 2.0;
    public float $defer_margin = 0.2;

    public function __construct(callable $M, callable $A, ?callable $gammaSamples=null, ?Budgets $budgets=null)
    {
        $this->M = $M;
        $this->A = $A;
        $this->gammaSamples = $gammaSamples ?? function(int $n){ return self::gammaPoints($n); };
        $this->budgets = $budgets ?? new Budgets();
    }

    
    /** Deterministic Γ points shared across languages (loads ../data/gamma_points_256.csv). */
    private static function gammaPoints(int $n): array
    {
        // repo layout: docs/notation/code_reference_v2 -> repo root is dirname(__DIR__, 3)
        $csvPath = dirname(__DIR__, 3) . "/data/gamma_points_256.csv";
        $rows = [];
        if (is_readable($csvPath)) {
            if (($h = fopen($csvPath, "r")) !== false) {
                $header = fgetcsv($h);
                while (($r = fgetcsv($h)) !== false) {
                    $row = array_combine($header, $r);
                    $rows[] = $row;
                }
                fclose($h);
            }
        }
        // fallback: simple Halton sequence (deterministic)
        $halton = function(int $i, int $base): float {
            $f = 1.0; $r = 0.0;
            while ($i > 0) { $f /= $base; $r += $f * ($i % $base); $i = intdiv($i, $base); }
            return $r;
        };

        $out = [];
        for ($k=0; $k<$n; $k++) {
            if (count($rows) > 0) {
                $row = $rows[$k % count($rows)];
                $rho = ["t" => floatval($row["rho_t"])];
                $theta = ["offset" => floatval($row["theta_offset"]), "wobble" => floatval($row["theta_wobble"])];
            } else {
                $i = ($k % 256) + 1;
                $rho = ["t" => $halton($i, 2)];
                $theta = ["offset" => 2.0*$halton($i, 3) - 1.0, "wobble" => 0.5*$halton($i, 5)];
            }
            $out[] = [$rho, $theta];
        }
        return $out;
    }

    /** @param array<float> $x */
    private static function l2(array $x): float {
        $s = 0.0;
        foreach ($x as $v) $s += $v*$v;
        return sqrt($s);
    }

    /** @param array<float> $a @param array<float> $b @return array<float> */
    private static function sub(array $a, array $b): array {
        $out = [];
        $n = min(count($a), count($b));
        for ($i=0;$i<$n;$i++) $out[] = $a[$i]-$b[$i];
        return $out;
    }

    /**
     * @param array<float> $y
     * @param array<float> $sHat
     * @return array{0:Gate,1:Evidence}
     */
    public function gate(array $y, array $sHat, Claim $claim): array
    {
        $notes = [];

        if ($this->budgets->max_compute <= 0.0) {
            return [Gate::REJECT, new Evidence(0,0,0,["Budget violation: compute <= 0"])];
        }

        $rho0 = ["mode"=>"nominal"];
        $ySig = ($this->M)($sHat, $rho0);
        $rSig = self::sub($y, $ySig);
        $scoreSig = self::l2($rSig);

        $bestArt = INF;
        foreach (($this->gammaSamples)(256) as $pair) {
            [$rho,$theta] = $pair;
            $yArt = ($this->A)($rho, $theta);
            $rArt = self::sub($y, $yArt);
            $sc = self::l2($rArt);
            if ($sc < $bestArt) $bestArt = $sc;
        }

        $gap = $bestArt - $scoreSig;
        $notes[] = sprintf("score_sig=%.4g, best_art=%.4g, gap=%.4g", $scoreSig, $bestArt, $gap);

        if (!is_finite($bestArt) || !is_finite($scoreSig)) {
            $notes[] = "Non-finite scores";
            return [Gate::REJECT, new Evidence($scoreSig,$bestArt,$gap,$notes)];
        }

        if ($scoreSig > 1e6 && $bestArt > 1e6) {
            $notes[] = "No closure: both fits poor";
            return [Gate::REJECT, new Evidence($scoreSig,$bestArt,$gap,$notes)];
        }

        if ($gap < $this->defer_margin) {
            $notes[] = "Non-identifiable under Γ → DEFER";
            return [Gate::DEFER, new Evidence($scoreSig,$bestArt,$gap,$notes)];
        }

        if ($gap >= $this->accept_margin) {
            $notes[] = "Signal robust under Γ → ACCEPT";
            return [Gate::ACCEPT, new Evidence($scoreSig,$bestArt,$gap,$notes)];
        }

        $notes[] = "Inconclusive gap → DEFER";
        return [Gate::DEFER, new Evidence($scoreSig,$bestArt,$gap,$notes)];
    }
}
