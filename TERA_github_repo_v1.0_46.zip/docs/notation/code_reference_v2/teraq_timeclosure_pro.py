"""    TERA / TERA-Q — Time-Closure (Pro) layer (v2.1)

This module adds the *time-integrated evidence* view:

    E_[t0,t1] = ∫_{t0}^{t1} w(t) Φ(y(t), ŝ(t)) dt

and a gate decision that depends on time-closure, not on a single snapshot.

Design goals:
  - Deterministic / auditable: no RNG; compatible with v2 deterministic Γ.
  - Minimal: implemented as a thin layer on top of the v2 reference engine.
  - Discrete-time friendly: uses a Riemann-sum approximation for the integral.

Intended use:
  - You already have a model that produces a time series of measurements y(t)
    and a corresponding predicted series ŝ(t) (or an estimator output).
  - You want a *single* gate decision that is stable across time and
    robust to transient artifacts.

NOTE:
  This file does NOT replace the v2 engine. It is an additive "Pro" file.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, List, Optional, Sequence, Tuple, Any

import math

# Import the minimal v2 engine types (kept stable for the bundle).
from teraq_v2 import TERAQ, Evidence, Gate, Claim


# ---------- Evidence accumulator (time-integrated) ----------

PhiFn = Callable[[Sequence[float], Sequence[float]], float]
WeightFn = Callable[[float], float]


def default_phi(y: Sequence[float], y_hat: Sequence[float]) -> float:
    """Default Φ: negative squared error (higher is better)."""
    n = min(len(y), len(y_hat))
    if n == 0:
        return 0.0
    return -sum((y[i] - y_hat[i]) ** 2 for i in range(n))


def default_w(t: float) -> float:
    """Default weight w(t)=1."""
    return 1.0


@dataclass(frozen=True)
class TimeEvidence:
    """Time-integrated evidence summary."""
    t0: float
    t1: float
    n_steps: int

    # Time-integrated scores (Riemann sum).
    E_signal: float
    E_artifact: float
    E_phi: float

    # Conservative summaries.
    worst_gap: float              # min gap across time (most adversarial moment)
    best_gap: float               # max gap across time
    mean_gap: float               # average gap

    # Diagnostics
    per_step_gate: Tuple[int, ...]  # +1/0/-1 per step
    per_step_gap: Tuple[float, ...]


class TimeClosureGate:
    """A deterministic time-closure gate built on the v2 engine."""

    def __init__(
        self,
        engine: TERAQ,
        phi: PhiFn = default_phi,
        w: WeightFn = default_w,
    ) -> None:
        self.engine = engine
        self.phi = phi
        self.w = w

    @staticmethod
    def _dt(times: Sequence[float], i: int) -> float:
        if i == 0:
            return times[1] - times[0] if len(times) > 1 else 1.0
        return times[i] - times[i - 1]

    def gate_time_series(
        self,
        claim: str,
        y_series: Sequence[Sequence[float]],
        yhat_series: Sequence[Sequence[float]],
        times: Optional[Sequence[float]] = None,
        *,
        # How to combine time into a final decision.
        # "conservative": take the minimum (worst) gap across time.
        # "integral": compare integrated evidence gaps.
        reducer: str = "conservative",
    ) -> Tuple[Gate, TimeEvidence]:
        """Return a single Gate using time-closure.

        Parameters
        ----------
        claim:
            The claim string (passed through to the v2 engine).
        y_series / yhat_series:
            Sequences of equal length. Each element is a vector measurement.
        times:
            Optional time stamps (same length). If missing, uses 0..N-1.
        reducer:
            "conservative" or "integral".

        Returns
        -------
        (Gate, TimeEvidence)
        """
        if len(y_series) != len(yhat_series):
            raise ValueError("y_series and yhat_series must have same length")

        n = len(y_series)
        if n == 0:
            raise ValueError("empty series")

        if times is None:
            times = list(range(n))
        if len(times) != n:
            raise ValueError("times must be same length as series")

        t0, t1 = float(times[0]), float(times[-1])

        # Normalize claim to the v2 Claim type once (do not rebuild per step).
        if isinstance(claim, Claim):
            cl = claim
        else:
            cl = Claim(text=str(claim), mts=[str(claim)])

        per_gate: List[int] = []
        per_gap: List[float] = []

        E_signal = 0.0
        E_art = 0.0
        E_phi = 0.0
        sum_dt = 0.0

        # Evaluate the v2 gate at each time step and integrate evidence.
        for i in range(n):
            dt = float(self._dt(times, i))
            if dt <= 0:
                dt = 1e-9  # keep deterministic, avoid zero/negative dt
            sum_dt += dt
            wt = float(self.w(float(times[i])))

            gate, ev = self.engine.gate(y_series[i], yhat_series[i], cl)

            # v2 Evidence gives *instantaneous* scores; we integrate them.
            E_signal += wt * ev.score_signal * dt
            E_art += wt * ev.score_artifact * dt
            E_phi += wt * self.phi(y_series[i], yhat_series[i]) * dt

            per_gate.append(int(gate.value))
            per_gap.append(float(ev.worst_case_gap))

        worst_gap = min(per_gap)
        best_gap = max(per_gap)
        mean_gap = sum(per_gap) / len(per_gap)

        # Decide final gate (time-aggregated).
        if reducer.lower() == "conservative":
            reduced_gap = worst_gap
        elif reducer.lower() == "integral":
            denom = sum_dt if sum_dt != 0 else 1.0
            reduced_gap = (E_art - E_signal) / denom
            # overwrite mean_gap with the integral gap to surface it
            mean_gap = reduced_gap
        else:
            raise ValueError("reducer must be 'conservative' or 'integral'")

        # Any hard REJECT at a step dominates (no valid closure for at least one snapshot).
        if any(g == int(Gate.REJECT) for g in per_gate):
            time_gate = Gate.REJECT
        else:
            # Mirror base TERA-Q decision logic on the reduced gap.
            if reduced_gap < self.engine.defer_margin:
                time_gate = Gate.DEFER
            elif reduced_gap >= self.engine.accept_margin:
                time_gate = Gate.ACCEPT
            else:
                time_gate = Gate.DEFER
        te = TimeEvidence(
            t0=t0, t1=t1, n_steps=n,
            E_signal=E_signal, E_artifact=E_art, E_phi=E_phi,
            worst_gap=worst_gap, best_gap=best_gap, mean_gap=mean_gap,
            per_step_gate=tuple(per_gate),
            per_step_gap=tuple(per_gap),
        )
        return time_gate, te
