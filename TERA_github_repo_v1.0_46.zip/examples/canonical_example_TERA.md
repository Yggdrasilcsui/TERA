# Canonical TERA Example (Claim → MTS → Gate Output)

Use this template for any domain (physics, chemistry, climate, medicine, engineering).

---

## 1) Claim / Question
Write one sentence.

Example:
> “A sprite (TLE) can occur without a parent lightning discharge.”

---

## 2) MTS (Minimal Testable Statement)
Write the smallest version that is still testable.

Example:
> A sprite occurs iff a parent discharge produces an upper-atmosphere electric field exceeding the local breakdown threshold for duration Δt,
> with correlated optical + VLF/ELF signatures.

---

## 3) Regime / Constraints
Specify the boundary conditions (the regime).

- Storm present: yes/no
- Altitude band: 50–90 km
- Timing window: Δt < 50 ms after parent discharge

---

## 4) Expected signature
What would you measure if the MTS is true?

- Optical transient above storm top
- Correlated VLF/ELF pulse
- Timing correlation: parent → sprite

---

## 5) Measurement plan (minimum)
- High-speed optical camera
- Photometer
- VLF/ELF receiver
- Lightning timestamping / location

---

## 6) Falsifier(s)
Write at least one “hard KO” condition.

Example:
- No parent discharge measured in the causal window → claim must be REJECT under this regime.

---

## 7) Gate output
- δ ∈ {ACCEPT, DEFER, REJECT}
- π ∈ [0,1]
- Missing Set (what else would improve closure)

Example:
- δ = REJECT
- π = 0.95
- Missing Set: none (already falsified)

---

## 8) Overshoot note (optional)
If the topic affects real-world resources, include a short O-vector note:
CO2eq / Water / Land / Toxicity / Critical Minerals / Circularity loss.
