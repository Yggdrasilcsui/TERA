# TERA-Q — Minerals: Beryl

Beryl (Be₃Al₂Si₆O₁₈) appendices for TERA-Q.

## Files

- `TERA-Q_Beryl_v1_Overview_MTS.pdf`
- `TERA-Q_Beryl_v2_Spectrum_Forensics.pdf`
- `TERA-Q_Beryl_v3_Isotopes_Bonding_Structure.pdf`
- `TERA-Q_Beryl_v4_Defects_ColorCenters_CrystalField.pdf`
- `TERA-Q_Beryl_v5_OpenProblems_MTS_Gates.pdf`
- `TERA-Q_Beryl_v6_DocumentedMeasurements_Top3Tests.pdf`
- `TERA-Q_Beryl_v7_AdvancedAppendix_GuestChannels_Zoning_Defects_Reset.pdf`
- `TERA-Q_Beryl_v8_ExperimentalRoadmap_UncertaintyClosure.pdf`
