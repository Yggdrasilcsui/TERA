SELFIE PLACEHOLDER
------------------
This folder can also contain a personal author photo / "TERA guardian" selfie.

Suggested filename:
  - author_selfie.jpg

Note:
  Keep it optional. The framework stands on its own.
