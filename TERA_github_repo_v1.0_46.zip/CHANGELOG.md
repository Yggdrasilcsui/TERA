# Changelog
## v1.0-v46 (2026-01-30)
- Add time-oriented notes: papers/anthropocene/TERA_Anthropocene_Note.pdf, papers/plastic/TERA_Plastic_Note.pdf.

## v1.0-v44 (2026-01-30)
- Add TERA-QV: quantum extension with effective space-viscosity η_R and optional adaptive gains.
- Add one-page notation PDF: docs/notation/TERA_QV_v44_onepage.pdf.

## v1.0-v43 — 2026-01-30
- Add TERA-Q reference implementation for open quantum systems (Lindblad + TERA stabilizer/filter)
- Add compact TERA-Q notation PDF (time-closure + gate mapping)

## v1.0.0 — 2026-01-22
- Public release seed: Manual, Notation, Disclaimer
- Water (41 anomalies) catalog + reproducibility appendix and datasets
- Lightning regimes + TLE coupling notes
- Validation gate, diamond/hypercube logic, accounting + tetrahedron memory notes